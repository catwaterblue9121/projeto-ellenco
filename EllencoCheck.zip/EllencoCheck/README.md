# EllencoCheck — Python + Flask + MySQL (XAMPP)

O projeto foi integrado com o CRUD de usuários em Python e o banco de
dados foi migrado de SQLite para **MySQL**, para rodar com o MySQL que
já vem junto do **XAMPP**.

## Pré-requisitos

- [XAMPP](https://www.apachefriends.org/) instalado, com o **MySQL**
  ligado no painel de controle (o Apache do XAMPP não é necessário —
  quem serve as páginas é o próprio Flask).
- Python 3.10+ instalado.

## Executar

```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Abra **http://localhost:5000**.

Na primeira execução, o backend conecta no MySQL do XAMPP e cria
automaticamente o banco `ellencocheck`, todas as tabelas e os dados
iniciais (equipamentos e itens de inspeção de exemplo). Não é preciso
mexer no phpMyAdmin manualmente — mas se preferir, o arquivo
`backend/schema.sql` pode ser importado por lá também (Aba **SQL** do
phpMyAdmin → colar o conteúdo do arquivo → Executar).

## Banco

O backend se conecta usando estes valores por padrão (iguais aos
padrões do XAMPP: usuário `root`, sem senha, porta `3306`):

| Variável         | Padrão        |
|------------------|---------------|
| `MYSQL_HOST`     | `localhost`   |
| `MYSQL_PORT`     | `3306`        |
| `MYSQL_USER`     | `root`        |
| `MYSQL_PASSWORD` | *(vazio)*     |
| `MYSQL_DATABASE` | `ellencocheck`|

Se o seu MySQL usa outra senha/porta, defina as variáveis de ambiente
correspondentes antes de rodar `python app.py`.

As tabelas do FrotaCheck/EllencoCheck:
- usuarios
- equipamentos
- tipos_equipamentos
- itens_inspecao
- checklists
- respostas_checklist
- password_reset_tokens

Funcionalidades:
- CRUD completo de usuários
- sessão de login
- recuperação de senha
- inspeções (checklists) por equipamento, filtradas pelo tipo de
  equipamento selecionado

## Usuários

Depois de entrar no sistema, abra **http://localhost:5000/usuarios.html**.

A senha é armazenada com hash usando Werkzeug.

## API de usuários

- POST `/api/usuarios`
- GET `/api/usuarios`
- GET `/api/usuarios/<id>`
- PUT `/api/usuarios/<id>`
- DELETE `/api/usuarios/<id>`

Também existem aliases `/api/users/...` e `/api/auth/...` para facilitar integração.

O DELETE desativa o usuário em vez de apagar fisicamente, preservando o histórico dos checklists.

## Correções feitas nesta revisão

- **Inspeções nunca eram salvas**: o frontend enviava os status em
  minúsculo (`"ok"`, `"problema"`, etc.) mas o banco só aceita os
  códigos em maiúsculo definidos no schema. Toda inspeção enviada
  falhava. Corrigido.
- **Checklist não filtrava pelo tipo de equipamento**: os itens de
  inspeção mostrados eram sempre todos os itens cadastrados, de todos
  os tipos de equipamento, em vez de só os itens do equipamento
  selecionado. Corrigido.
- **Banco de dados nunca era inicializado**: `inicializar_banco()`
  era importado mas nunca chamado em `app.py`; só "funcionava" porque
  havia um `frotacheck.db` pronto dentro do repositório. Corrigido —
  agora é chamado automaticamente ao iniciar o servidor.
- **Erros de data/hora com o MySQL**: os timestamps eram gravados em
  formato ISO 8601 com timezone (`2026-09-10T18:27:13+00:00`), que o
  SQLite aceitava por ser apenas texto, mas o MySQL rejeitava por não
  ser um `DATETIME` válido. Corrigido.
- **`/api/checklists` (POST) sem autenticação**: qualquer requisição
  sem login conseguia gravar inspeções. Agora exige login.
- **Status do equipamento exibido errado**: um bug de precedência de
  operadores (`??` vs `? :`) no JavaScript invertia o texto mostrado.
  Corrigido.
- **Logout incompleto**: `sair()` só limpava o navegador, sem avisar
  o backend para encerrar a sessão no servidor. Corrigido.
- **Migração SQLite → MySQL**: novo `backend/schema.sql` e
  `backend/database.py`, com `ENUM`s para os status, chaves
  estrangeiras e compatibilidade com o MySQL do XAMPP.

Todo o fluxo (cadastro, login, esqueci minha senha, redefinir senha,
inspeção completa de equipamento, listagem de usuários/equipamentos)
foi testado de ponta a ponta contra um MySQL real antes da entrega.
