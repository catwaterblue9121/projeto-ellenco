-- =====================================================================
-- EllencoCheck - Schema MySQL (compatível com XAMPP / phpMyAdmin)
-- =====================================================================
-- Como usar:
--   1) Abra o phpMyAdmin (http://localhost/phpmyadmin) com o XAMPP ligado.
--   2) Vá em "SQL" e cole/execute todo este arquivo.
--      (Ele cria o banco "ellencocheck" e todas as tabelas + dados iniciais.)
--   OU
--   1) Deixe o Apache/MySQL do XAMPP ligados.
--   2) Rode "python app.py" - o backend cria o banco e as tabelas
--      automaticamente na primeira execução (veja backend/database.py).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ellencocheck
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE ellencocheck;

-- ---------------------------------------------------------------------
-- Tipos de equipamento
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tipos_equipamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL UNIQUE,
    descricao TEXT,
    ativo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Equipamentos
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS equipamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_id INT NOT NULL,
    nome VARCHAR(150) NOT NULL,
    patrimonio VARCHAR(100) UNIQUE,
    modelo VARCHAR(100),
    fabricante VARCHAR(100),
    placa VARCHAR(20),
    ano INT,
    horimetro DECIMAL(10,2) NOT NULL DEFAULT 0,
    status ENUM('ATIVO','MANUTENCAO','INATIVO') NOT NULL DEFAULT 'ATIVO',
    observacoes TEXT,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_equipamentos_tipo FOREIGN KEY (tipo_id)
        REFERENCES tipos_equipamentos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Itens de inspeção (checklist) por tipo de equipamento
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS itens_inspecao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_id INT NOT NULL,
    nome VARCHAR(200) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100) NOT NULL DEFAULT 'Geral',
    ordem INT NOT NULL DEFAULT 0,
    obrigatorio TINYINT(1) NOT NULL DEFAULT 1,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    CONSTRAINT fk_itens_tipo FOREIGN KEY (tipo_id)
        REFERENCES tipos_equipamentos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Usuários
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Checklists (inspeções realizadas)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS checklists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipamento_id INT NOT NULL,
    usuario_id INT NOT NULL,
    horimetro DECIMAL(10,2) NOT NULL DEFAULT 0,
    status ENUM('APROVADO','APROVADO_COM_OBSERVACAO','REPROVADO') NOT NULL,
    observacoes TEXT,
    realizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_checklists_equipamento FOREIGN KEY (equipamento_id)
        REFERENCES equipamentos(id),
    CONSTRAINT fk_checklists_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Respostas de cada item do checklist
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS respostas_checklist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    checklist_id INT NOT NULL,
    item_inspecao_id INT NOT NULL,
    status ENUM('OK','ATENCAO','PROBLEMA','NAO_APLICAVEL') NOT NULL,
    observacao TEXT,
    respondido_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_resposta_checklist_item (checklist_id, item_inspecao_id),
    CONSTRAINT fk_respostas_checklist FOREIGN KEY (checklist_id)
        REFERENCES checklists(id) ON DELETE CASCADE,
    CONSTRAINT fk_respostas_item FOREIGN KEY (item_inspecao_id)
        REFERENCES itens_inspecao(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Tokens de recuperação de senha
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token_hash VARCHAR(64) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    expiry_date DATETIME NOT NULL,
    used TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reset_usuario FOREIGN KEY (user_id)
        REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_checklists_equipamento ON checklists(equipamento_id);
CREATE INDEX idx_checklists_usuario ON checklists(usuario_id);
CREATE INDEX idx_itens_tipo ON itens_inspecao(tipo_id);

-- =====================================================================
-- Dados iniciais (seed)
-- =====================================================================

INSERT IGNORE INTO tipos_equipamentos (id,nome,descricao,ativo) VALUES
(1,'Escavadeira','Máquina para escavação e movimentação de materiais',1),
(2,'Retroescavadeira','Equipamento para escavação e carregamento',1),
(3,'Pá Carregadeira','Máquina para carregamento e movimentação',1),
(4,'Motoniveladora','Máquina para nivelamento de terrenos',1),
(5,'Rolo Compactador','Equipamento para compactação',1);

INSERT IGNORE INTO equipamentos
(id,tipo_id,nome,patrimonio,modelo,fabricante,horimetro,status,ativo) VALUES
(1,1,'Escavadeira 01','EQ-001','320','Caterpillar',1250.50,'ATIVO',1),
(2,2,'Retroescavadeira 01','EQ-002','416F2','Caterpillar',980.20,'ATIVO',1);

INSERT IGNORE INTO itens_inspecao
(id,tipo_id,nome,descricao,categoria,ordem,obrigatorio,ativo) VALUES
(1,1,'Nível do óleo do motor','Verificar se o nível está adequado.','Motor',1,1,1),
(2,2,'Nível do óleo do motor','Verificar se o nível está adequado.','Motor',1,1,1),
(4,1,'Nível do líquido de arrefecimento','Verificar nível e sinais de vazamento.','Motor',2,1,1),
(5,1,'Vazamentos hidráulicos','Verificar mangueiras, conexões e cilindros.','Hidráulica',3,1,1),
(6,1,'Estado das esteiras','Verificar desgaste, tensão e danos.','Material Rodante',4,1,1),
(7,2,'Pneus','Verificar calibragem, desgaste e danos.','Rodagem',2,1,1);
