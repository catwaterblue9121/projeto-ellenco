"""
Camada de acesso ao banco de dados do EllencoCheck.

Este projeto agora usa um banco MySQL separado (pensado para rodar com o
MySQL que vem junto do XAMPP), em vez do SQLite usado anteriormente.

Configuração (opcional): defina variáveis de ambiente para apontar para
outro servidor MySQL. Se nada for definido, os valores padrão já
funcionam com uma instalação padrão do XAMPP (usuário "root", sem senha,
porta 3306):

    MYSQL_HOST       (padrão: localhost)
    MYSQL_PORT       (padrão: 3306)
    MYSQL_USER       (padrão: root)
    MYSQL_PASSWORD   (padrão: "" — vazio, como no XAMPP)
    MYSQL_DATABASE   (padrão: ellencocheck)

Na primeira execução, `inicializar_banco()` cria o banco de dados
"ellencocheck" (caso não exista) e todas as tabelas/dados iniciais,
lendo o arquivo schema.sql que fica ao lado deste módulo. Não é preciso
criar nada manualmente no phpMyAdmin, mas o schema.sql também pode ser
importado por lá se for preferível.
"""

import os
import re
from pathlib import Path

import pymysql
import pymysql.cursors

BASE_DIR = Path(__file__).resolve().parent
SCHEMA_FILE = BASE_DIR / "schema.sql"

MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.environ.get("MYSQL_PORT", "3306"))
MYSQL_USER = os.environ.get("MYSQL_USER", "root")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.environ.get("MYSQL_DATABASE", "ellencocheck")


class Cursor:
    """Fina camada de compatibilidade sobre o cursor do PyMySQL.

    Mantém a mesma "sensação" da API do sqlite3 usada no restante do
    projeto (placeholders "?", .fetchone()/.fetchall(), .lastrowid),
    para que app.py precise de pouquíssimas mudanças.
    """

    def __init__(self, raw_cursor):
        self._cursor = raw_cursor

    @staticmethod
    def _to_mysql(sql):
        # Os placeholders do projeto usam "?" (estilo sqlite3).
        # O PyMySQL espera "%s".
        return sql.replace("?", "%s")

    def execute(self, sql, params=()):
        self._cursor.execute(self._to_mysql(sql), params)
        return self

    def fetchone(self):
        return self._cursor.fetchone()

    def fetchall(self):
        return self._cursor.fetchall()

    @property
    def lastrowid(self):
        return self._cursor.lastrowid


class Connection:
    """Fina camada de compatibilidade sobre a conexão do PyMySQL."""

    def __init__(self, raw_conn):
        self._conn = raw_conn

    def execute(self, sql, params=()):
        cur = Cursor(self._conn.cursor())
        cur.execute(sql, params)
        return cur

    def executescript(self, script):
        """Executa múltiplos statements separados por ';'.

        (O PyMySQL, diferente do sqlite3, não roda vários comandos de
        uma vez, então dividimos o script em statements individuais.)
        """
        statements = _split_sql_statements(script)
        cur = self._conn.cursor()
        for statement in statements:
            statement = statement.strip()
            if not statement:
                continue
            try:
                cur.execute(statement)
            except pymysql.err.OperationalError as exc:
                # 1061 = "Duplicate key name": acontece ao rodar o
                # schema novamente (CREATE INDEX não tem um "IF NOT
                # EXISTS" totalmente confiável entre versões do
                # MySQL/MariaDB). Como as tabelas já usam
                # "IF NOT EXISTS", é seguro ignorar só este caso.
                if exc.args and exc.args[0] == 1061:
                    continue
                raise
        return cur

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()


def _split_sql_statements(script):
    """Divide um script SQL em statements individuais, ignorando os ';'
    que aparecem dentro de comentários "--" de cada linha."""
    statements = []
    buffer = []
    for linha in script.splitlines():
        sem_comentario = re.sub(r"--.*$", "", linha)
        buffer.append(sem_comentario)
        if sem_comentario.strip().endswith(";"):
            statements.append("\n".join(buffer))
            buffer = []
    if buffer:
        resto = "\n".join(buffer).strip()
        if resto:
            statements.append(resto)
    return statements


def _conectar_sem_banco():
    """Conecta ao servidor MySQL sem selecionar um banco específico,
    usado apenas para garantir que o banco "ellencocheck" exista."""
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )


def conectar():
    """Abre uma conexão com o banco "ellencocheck" já selecionado."""
    raw_conn = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )
    return Connection(raw_conn)


def inicializar_banco():
    """Cria o banco de dados (se necessário) e roda o schema.sql,
    que cria as tabelas e insere os dados iniciais."""
    conn = _conectar_sem_banco()
    try:
        with conn.cursor() as cur:
            cur.execute(
                f"CREATE DATABASE IF NOT EXISTS `{MYSQL_DATABASE}` "
                "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
        conn.commit()
    finally:
        conn.close()

    script = SCHEMA_FILE.read_text(encoding="utf-8")
    conn = conectar()
    try:
        conn.executescript(script)
        conn.commit()
    finally:
        conn.close()
